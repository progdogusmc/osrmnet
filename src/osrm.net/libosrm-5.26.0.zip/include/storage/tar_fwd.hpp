#ifndef OSRM_STORAGE_TAR_FWD_HPP_
#define OSRM_STORAGE_TAR_FWD_HPP_

namespace osrm
{
namespace storage
{
namespace tar
{

class FileReader;
class FileWriter;

} // namespace tar
} // namespace storage
} // namespace osrm

#endif
